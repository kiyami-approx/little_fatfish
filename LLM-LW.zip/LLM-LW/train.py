# -*- coding: utf-8 -*-
"""
train.py —— 第 3 步：训练

用法：
    python train.py                     # 训练 + 评估 + 自动挑置信度阈值
    python train.py --chat              # 训练完直接进聊天模式
    python train.py --epochs 2000 --hidden 64 --lr 0.4

跑完会生成 model.npz，下一步 export_weights.py 会用它导出成 C 数组。

【训练在做什么】
    重复很多轮（epoch），每一轮：
      1. 把全部训练样本喂进去，前向算出每句话属于每一类的概率  forward()
      2. 用交叉熵衡量"预测得有多离谱"                          cross_entropy()
      3. 反向求出每个权重的梯度，沿反方向挪一小步                backward()
    重复几千次，权重就自己调到能分类的位置了。

【置信度阈值是干嘛的】
    模型被逼着"必须选一个类别"，所以哪怕输入是它从没见过的东西，它也会硬选一个。
    解决办法：推理时看最高概率，低于阈值就直接判成 unknown。
    这个阈值不用手调，下面的 tune_threshold() 会在验证集上自动挑最好的那个。
"""

import argparse
import os
import numpy as np

from dataset import (FEAT_DIM, CONTEXT_W, featurize, featurize_ctx,
                     build_raw_dataset, augment_texts, all_texts, response_of)
from model import MLP, cross_entropy, softmax

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "model.npz")


def split_indices(y, n_val_per_class=2, seed=42):
    """
    按类别划分训练集 / 验证集。

    每一类里随机抽 n_val_per_class 条当验证集，剩下的训练。
    验证集的作用：检验模型是"真学会了"还是"把训练集背下来了"。

    返回: (训练集下标数组, 验证集下标数组)
    """
    rng = np.random.default_rng(seed)
    train_idx, val_idx = [], []

    for c in np.unique(y):
        idx = np.where(y == c)[0]
        rng.shuffle(idx)
        n_val = min(n_val_per_class, max(1, len(idx) - 2))   # 每类至少留 2 条训练
        val_idx.extend(idx[:n_val].tolist())
        train_idx.extend(idx[n_val:].tolist())

    return np.array(train_idx), np.array(val_idx)


def build_context_training_set(texts, labels, seed=321):
    """
    给训练集配上"上一句"，造出带上下文的样本。

    模拟三种真实场景：
      · 一半样本当作"对话第一句"，没有上下文
      · 约三分之一样本，上一句取同类的另一条说法（用户在同一话题上追问）
      · 剩下约六分之一，上一句从随便哪个类里取（用户突然换话题）

    这样模型会学到"上下文只是辅助线索"：同一话题时借力，
    换话题时也不会被上一句带偏。

    返回: (X_ctx, y_ctx)
    """
    rng = np.random.default_rng(seed)
    by_class = {}
    for i, c in enumerate(labels):
        by_class.setdefault(int(c), []).append(i)

    X_list, y_list = [], []
    for i, (text, label) in enumerate(zip(texts, labels)):
        r = float(rng.random())
        prev = None

        if r < 0.35:                                  # 同类追问
            pool = by_class[int(label)]
            if len(pool) > 1:
                j = pool[int(rng.integers(len(pool)))]
                if j != i:
                    prev = texts[j]
        elif r < 0.50:                                # 换话题
            prev = texts[int(rng.integers(len(texts)))]

        X_list.append(featurize_ctx(text, prev))
        y_list.append(int(label))

    return np.stack(X_list).astype(np.float32), np.array(y_list, dtype=np.int64)


def apply_threshold(prob, threshold, unknown_id):
    """
    带阈值的预测：最高概率低于阈值就改判 unknown。

    参数: prob       -- shape=(N, 类别数) 的概率
          threshold  -- 阈值
          unknown_id -- unknown 类的编号
    返回: (预测编号数组, 对应的置信度数组)
    """
    cid = np.argmax(prob, axis=1)
    conf = prob[np.arange(prob.shape[0]), cid]
    cid = np.where(conf < threshold, unknown_id, cid)
    return cid, conf


def accuracy(model, X, y):
    """不带阈值的准确率（纯看模型自己的判断）。"""
    if X.shape[0] == 0:
        return 0.0
    return float(np.mean(model.predict(X) == y))


def tune_threshold(prob, yva, unknown_id):
    """
    扫一遍阈值，挑准确率最高的那个。

    参数: prob -- shape=(N, 类别数) 的概率（记得先做温度缩放，否则模型过自信，阈值没用）
    返回: (最佳阈值, 该阈值下的准确率)

    阈值太低 -> 什么都不拦，怪句子照样被硬判成某个类别
    阈值太高 -> 正常句子也被判成"不懂"，变成一问三不知
    """
    best_thr, best_acc = 0.0, -1.0

    for thr in np.arange(0.05, 0.90, 0.05):
        cid, _ = apply_threshold(prob, float(thr), unknown_id)
        acc = float(np.mean(cid == yva))
        if acc > best_acc:
            best_acc, best_thr = acc, float(thr)

    return best_thr, best_acc


def fit_temperature(logits, y):
    """
    在验证集上找一个"温度"，让输出概率变得诚实。

    模型天生过自信：哪怕是它没见过的句子，也敢给出 0.95 的置信度。
    把 logits 统一除以一个大于 1 的温度 T 再 softmax，概率就被压平，
    不懂的句子置信度自然降下来，阈值才拦得住。
    这里用"找让验证集交叉熵最小的 T"来定它。

    返回: 温度 T（> 1 说明模型原来确实过自信）
    """
    idx = np.arange(len(y))
    best_T, best_nll = 1.0, float("inf")

    for T in np.arange(0.5, 6.0, 0.1):
        p = softmax(logits / T)
        nll = float(-np.mean(np.log(np.clip(p[idx, y], 1e-9, 1.0))))
        if nll < best_nll:
            best_nll, best_T = nll, float(T)

    return best_T


def main():
    parser = argparse.ArgumentParser(description="训练小肥鱼的对话模型（纯 numpy）")
    parser.add_argument("--epochs", type=int, default=2500, help="训练轮数")
    parser.add_argument("--lr", type=float, default=0.4, help="学习率")
    parser.add_argument("--hidden", type=int, default=64, help="隐藏层神经元个数")
    parser.add_argument("--l2", type=float, default=1e-3, help="L2 正则强度")
    parser.add_argument("--seed", type=int, default=0, help="随机种子")
    parser.add_argument("--chat", action="store_true", help="训练完进入聊天模式")
    args = parser.parse_args()

    # ---------------- 准备数据 ----------------
    X, y, tags, responses = build_raw_dataset()
    texts = all_texts()          # 顺序和 build_raw_dataset 完全一致，用来打印"哪句错了"
    n_class = len(tags)
    unknown_id = tags.index("unknown")

    # 先在"原始样本"上划分训练/验证，保证验证集干净
    # 每类留 3 条做验证：留 2 条的话一共才 72 题，错一道就掉 1.4%，
    # 数字抖得厉害，看不出改进到底有没有用
    tr_idx, va_idx = split_indices(y, n_val_per_class=3, seed=42)
    Xtr, ytr = X[tr_idx], y[tr_idx]
    Xva, yva = X[va_idx], y[va_idx]
    n_raw_tr = Xtr.shape[0]

    # 再给训练集加两类样本（验证集一条都不加）：
    #   ① 带上下文的样本：模拟"用户在同一话题上连着追问"
    #   ② 残缺句样本：模拟打字不全、说漏字
    tr_texts = [texts[i] for i in tr_idx]
    Xctx, yctx = build_context_training_set(tr_texts, ytr, seed=321)
    Xa, ya = augment_texts(tr_texts, ytr, n_aug=2, seed=999)
    Xtr = np.vstack([Xtr, Xctx, Xa])
    ytr = np.concatenate([ytr, yctx, ya])

    print("=" * 66)
    print("类别 %d 个   原始样本 %d 条   特征 %d 维" % (n_class, X.shape[0], FEAT_DIM))
    print("训练集 %d 条（原始 %d + 带上下文 %d + 残缺失真 %d）"
          % (Xtr.shape[0], n_raw_tr, Xctx.shape[0], Xa.shape[0]))
    print("验证集 %d 条（干净的原始样本，不带上下文）" % Xva.shape[0])
    print("=" * 66)

    # ---------------- 建模型 ----------------
    model = MLP(n_in=FEAT_DIM, n_hidden=args.hidden, n_out=n_class, seed=args.seed)
    n_param = model.W1.size + model.b1.size + model.W2.size + model.b2.size
    print("参数量 %d 个（float32 约 %.1f KB）"
          % (n_param, n_param * 4 / 1024.0))

    # 类别权重：只给 unknown 类加权。
    #
    # 这里踩过一个坑，记下来：一开始用的是"样本越少的类权重越高"（len/counts），
    # 结果 unknown 因为是样本最多的类（133 条），权重被压到 0.2，
    # 模型就变成"宁可瞎猜也不说不知道"，兜底率从 66.7% 掉到 40.6%。
    #
    # unknown 是特殊的：它是"其他所有东西"的集合，样本之间没有共同特征，
    # 天生就很难学，所以给它一点加权，让"该说不懂"这件事更被重视。
    #
    # 但千万不能给太多。曾经用 2.0，错例分析一看就露馅了：
    # time / help / why / name / greet 这些正常类别各有 4~5 条被判成 unknown。
    # 原因是 unknown 本身就占了 133 条样本、已经是最大的一类，
    # 再乘 2 倍权重，它就开始"欺负"别人了。
    # 现在降到 1.2：保留一点兜底倾向，又不至于把正常句子吸走。
    class_w = np.ones(n_class, dtype=np.float32)
    class_w[unknown_id] = 1.2
    sample_w = class_w[ytr]
    print("类别权重：unknown 类 = %.1f，其余 = 1.0" % class_w[unknown_id])

    # ---------------- 训练 ----------------
    report_every = max(1, args.epochs // 12)
    eval_every = max(1, args.epochs // 100)      # 每 1% 的进度评估一次，用于早停
    print("\n开始训练（每 %d 轮打印一次）" % report_every)
    print("-" * 66)
    print("%8s %12s %12s %12s" % ("epoch", "loss", "训练准确率", "验证准确率"))

    best_val_acc, best_epoch, best_state = -1.0, 0, None

    for epoch in range(1, args.epochs + 1):
        model.forward(Xtr)                       # 1) 前向
        loss = cross_entropy(model.p, ytr)       # 2) 算损失（只观察，不参与更新）
        model.backward(ytr, lr=args.lr, l2=args.l2, momentum=0.9,
                       sample_weight=sample_w)   # 3) 反向 + 更新

        if epoch % report_every == 0 or epoch == 1:
            print("%8d %12.5f %11.1f%% %11.1f%%"
                  % (epoch, loss,
                     accuracy(model, Xtr, ytr) * 100.0,
                     accuracy(model, Xva, yva) * 100.0))

        # 早停：随手记住验证集上表现最好的那一版权重。
        # 训练到后面会开始过拟合（训练集还在涨，验证集反而往下掉），
        # 我们要的是"泛化最好"的那一刻，不是最后一刻。
        if epoch % eval_every == 0 or epoch == args.epochs:
            val_acc = accuracy(model, Xva, yva)
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                best_epoch = epoch
                best_state = (model.W1.copy(), model.b1.copy(),
                              model.W2.copy(), model.b2.copy())

    # 回滚到验证集最好的那一版
    if best_state is not None and best_epoch != args.epochs:
        model.W1, model.b1, model.W2, model.b2 = best_state
        print("-" * 66)
        print("早停：回滚到第 %d 轮（验证集最好 %.1f%%）"
              % (best_epoch, best_val_acc * 100.0))

    # ---------------- 评估 ----------------
    acc_tr = accuracy(model, Xtr, ytr) * 100.0
    acc_va = accuracy(model, Xva, yva) * 100.0
    print("-" * 66)
    print("训练集准确率 %.1f%%    验证集准确率 %.1f%%（未加阈值）" % (acc_tr, acc_va))
    if acc_tr - acc_va > 15.0:
        print("⚠️  训练集明显高于验证集 = 过拟合。"
              "加更多说法、调大 --l2 或调小 --hidden 都能缓解。")

    # ---------------- 温度缩放 + 自动挑置信度阈值 ----------------
    logits_va = model.logits(Xva)
    temperature = fit_temperature(logits_va, yva)
    prob_va = softmax(logits_va / temperature)
    print("温度缩放：T = %.1f（>1 说明模型原来过自信，概率被压平了）" % temperature)

    best_thr, best_acc = tune_threshold(prob_va, yva, unknown_id)
    print("自动挑选的置信度阈值：%.2f  ->  验证集准确率 %.1f%%"
          % (best_thr, best_acc * 100.0))

    # 给阈值加个下限。
    # 自动调优经常给出 0.05（等于完全不拦截），因为验证集里全是"有明确意图"的句子，
    # 不拦当然分数最高。但真实聊天里有大量模糊输入（"太阳真大"这种），
    # 不拦就会乱答。这里宁可多回一句"不太懂"，也要少答错。
    MIN_THRESHOLD = 0.35
    if best_thr < MIN_THRESHOLD:
        best_thr = MIN_THRESHOLD
        cid_thr, _ = apply_threshold(prob_va, best_thr, unknown_id)
        print("阈值下限生效：提高到 %.2f（这时验证集准确率 %.1f%%，"
              "用一点准确率换取更少的乱答）"
              % (best_thr, float(np.mean(cid_thr == yva)) * 100.0))

    # 看看兜底能力：验证集里"本来就不该懂"的句子，有多少被成功拦下来了
    raw_cid = np.argmax(prob_va, axis=1)
    is_unknown_true = (yva == unknown_id)
    if np.any(is_unknown_true):
        raw_hit = float(np.mean(raw_cid[is_unknown_true] == unknown_id)) * 100.0
        thr_cid, _ = apply_threshold(prob_va, best_thr, unknown_id)
        thr_hit = float(np.mean(thr_cid[is_unknown_true] == unknown_id)) * 100.0
        print("杂句兜底率：不加阈值 %.1f%%  ->  加阈值 %.1f%%" % (raw_hit, thr_hit))

    # 把验证集里认错的句子列出来，方便回头补数据
    thr_cid, _ = apply_threshold(prob_va, best_thr, unknown_id)
    wrong = np.where(thr_cid != yva)[0]
    if wrong.size > 0:
        print("\n验证集里还认错的句子（照着这些补说法，模型最容易进步）：")
        for i in wrong[:15]:
            gi = va_idx[i]
            print("   %-16s 认成了 %-10s (应该是 %s)"
                  % (texts[gi], tags[thr_cid[i]], tags[yva[i]]))

    # ---------------- 保存 ----------------
    model.save(MODEL_PATH, tags, responses, FEAT_DIM, args.hidden,
               threshold=best_thr, temperature=temperature)
    print("\n权重已保存到：%s" % MODEL_PATH)
    print("下一步：python export_weights.py   （导出成单片机能用的 C 数组）")

    # ---------------- 可选：聊天 ----------------
    if args.chat:
        chat_loop(model, tags, responses, unknown_id, best_thr, temperature)


def predict_one(model, text, unknown_id, threshold, temperature, prev_text=None):
    """
    对一句话做一次带阈值 + 温度缩放 + 上下文的预测，返回 (类别编号, 置信度)。

    注意两个顺序都很讲究：
      · softmax 是按"一批样本"写的（内部用 axis=1），所以要先把 [0] 放在 softmax 外面，
        不能写成 softmax(logits[0]) —— 那样会变成一维数组，softmax 直接报错
      · 先除以温度把概率压平，再和阈值比

    参数: prev_text -- 用户上一句说了什么（没有就传 None）。用来提供对话上下文。
    """
    f = featurize_ctx(text, prev_text).reshape(1, -1)
    prob = softmax(model.logits(f) / temperature)[0]
    cid = int(np.argmax(prob))
    conf = float(prob[cid])
    if conf < threshold:
        cid = unknown_id
    return cid, conf


def chat_loop(model, tags, responses, unknown_id, threshold, temperature):
    """简单的命令行聊天，用来直观感受模型认得哪些说法、认不得哪些。"""
    print("\n" + "=" * 66)
    print("进入聊天模式（输入 q 退出）")
    print("试试：连着聊同一个话题（比如先说'你会什么'，再说'那除了这些呢'）")
    print("      随口闲聊、以及四则运算（比如 12*8）")
    print("=" * 66)

    prev_text = None          # 记住用户上一句，用来提供对话上下文
    turn = 0                  # 对话轮数，用来在同类的几句回复里轮换

    while True:
        try:
            text = input("\n你     > ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if text.lower() in ("q", "quit", "exit"):
            break
        if not text:
            continue

        cid, conf = predict_one(model, text, unknown_id, threshold, temperature,
                                prev_text=prev_text)
        reply = response_of(responses, cid, tags, text, turn=turn)
        print("小肥鱼 > %s" % reply)
        print("         [意图 %s，置信度 %.2f%s]"
              % (tags[cid], conf, "，参考了上一句" if prev_text else ""))

        prev_text = text
        turn += 1


if __name__ == "__main__":
    main()
