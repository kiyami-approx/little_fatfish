# -*- coding: utf-8 -*-
"""
export_weights.py —— 第 4 步：把训练好的权重导出成 C 数组（通往 M2 的桥）

用法：
    python export_weights.py

产出：
    model_weights.h   —— 直接丢进 STM32 工程就能用的头文件

这个脚本做三件事：
  1. 把 model.npz 里的权重写成 C 数组，顺手算好单片机上会占多少 Flash
  2. 把回复文本写成字符串表（MCU 端查表就完事，不需要生成文本）
  3. 打印"回复里用到的所有汉字"，M2 阶段要给这些字准备 OLED 字模

【M2 要做的事，先在这里交代清楚】
  MCU 端要复现三段逻辑，公式必须和 dataset.py / model.py 一模一样：

  ① 特征提取（对应 dataset.featurize）
       - UTF-8 解码成 Unicode 码点，纠正常见错字，丢掉空格和标点
       - 逐字：
            feat[code % 512] += 1
            feat[(上一个字 * 31 + 这个字) % 512] += 1
            feat[(这个字 * 31 + 下一个字) % 512] += 1
       - 整条向量除以它的 L2 长度

  ② 前向推理（对应 model.MLP.logits + softmax）
       z1 = X @ W1 + b1 ;  a1 = ReLU(z1)
       z2 = a1 @ W2 + b2
       p  = softmax(z2 / MODEL_TEMPERATURE)      ← 别忘了这个温度除法

  ③ 判决（对应 train.apply_threshold）
       取 p 中最大值的下标 i 和概率 conf
       如果 conf < MODEL_THRESHOLD，就强制改成 unknown 那一类
       回复就是 MODEL_RESPONSES[i]

  ④ 算术题（calc 类）特殊处理
       如果判出来是 calc 类，不要直接查回复表，
       而是先用 C 版的 parse_calc() 把算式解出来（规则见 dataset.parse_calc），
       算得出来就回算式结果，算不出来才用它表里的兜底回复。

  ⚠️ 温度是"除以"不是"乘以"：p = softmax(z2 / T)。
     T < 1 表示模型输出偏保守，要锐化一下。
"""

import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "model.npz")
HEADER_PATH = os.path.join(HERE, "model_weights.h")

# 导出后用来"对拍"的测试句子：M2 阶段在板子上跑同样几句，结果应该完全一致
TEST_SENTENCES = [
    "你好", "你是谁", "谢谢你", "我不开心", "现在几点", "苹果好吃吗",
    "3+5", "十二减四", "7除2", "8*9",
]


def fmt_float_array(name, arr, per_line=8):
    """把一个 numpy 数组格式化成 C 的 float 数组定义。"""
    flat = arr.flatten().astype(np.float32)
    lines = []
    for i in range(0, flat.size, per_line):
        chunk = ", ".join("%.6ff" % float(v) for v in flat[i:i + per_line])
        lines.append("    " + chunk + ",")
    return ("static const float %s[%d] = {\n%s\n};\n"
            % (name, flat.size, "\n".join(lines)))


def main():
    if not os.path.exists(MODEL_PATH):
        raise SystemExit("找不到 model.npz，请先运行：python train.py")

    data = np.load(MODEL_PATH, allow_pickle=False)
    W1 = data["W1"].astype(np.float32)
    b1 = data["b1"].astype(np.float32)
    W2 = data["W2"].astype(np.float32)
    b2 = data["b2"].astype(np.float32)
    tags = [str(t) for t in data["tags"]]
    responses = [[str(x) for x in row] for row in data["responses"]]
    feat_dim = int(data["feat_dim"])
    hidden = int(data["hidden"])
    hash_mul = int(data["hash_mul"])
    threshold = float(data["threshold"]) if "threshold" in data else 0.0
    temperature = float(data["temperature"]) if "temperature" in data else 1.0
    n_class = W2.shape[1]
    unknown_id = tags.index("unknown") if "unknown" in tags else -1

    n_param = W1.size + b1.size + W2.size + b2.size
    print("=" * 64)
    print("结构：%d -> %d -> %d" % (feat_dim, hidden, n_class))
    print("参数：%d 个，权重自身占 Flash 约 %.1f KB"
          % (n_param, n_param * 4 / 1024.0))
    print("置信度阈值 %.2f    温度系数 %.1f    unknown 类编号 %d"
          % (threshold, temperature, unknown_id))
    print("=" * 64)

    # ---------------- 生成 C 头文件 ----------------
    out = []
    out.append("/* ============================================================================")
    out.append(" * model_weights.h —— 由 export_weights.py 自动生成，请不要手改")
    out.append(" *")
    out.append(" * 小肥鱼对话模型的权重 + 回复表，直接 include 进 MCU 工程即可。")
    out.append(" * 网络结构：%d 维特征 -> %d 个隐藏神经元(ReLU) -> %d 个类别(Softmax)"
               % (feat_dim, hidden, n_class))
    out.append(" * 参数量  ：%d 个 float，占 Flash 约 %.1f KB" % (n_param, n_param * 4 / 1024.0))
    out.append(" *")
    out.append(" * 【MCU 端必须复现的流程，公式要和 dataset.py / model.py 完全一致】")
    out.append(" *")
    out.append(" * 1) 特征提取：")
    out.append(" *      UTF-8 解码成码点 -> 纠正常见错字 -> 丢掉空格和标点 ->")
    out.append(" *      feat[code %% %d] += 1" % feat_dim)
    out.append(" *      feat[(prev * %d + code) %% %d] += 1     (prev 是上一个字的码点)"
               % (hash_mul, feat_dim))
    out.append(" *      feat[(code * %d + next) %% %d] += 1     (next 是下一个字的码点)"
               % (hash_mul, feat_dim))
    out.append(" *      feat[((prev2 * %d + prev) * %d + code) %% %d] += 0.5   (三字组合)"
               % (hash_mul, hash_mul, feat_dim))
    out.append(" *      最后整条向量除以它的 L2 长度（sqrt(sum(x*x))）")
    out.append(" *")
    out.append(" * 2) 前向推理：")
    out.append(" *      z1 = X*W1 + b1  ->  a1 = ReLU(z1)")
    out.append(" *      z2 = a1*W2 + b2")
    out.append(" *      p  = softmax(z2 / MODEL_TEMPERATURE)     <-- 这里要除以温度")
    out.append(" *")
    out.append(" * 3) 判决：取 p 中最大值的下标 i 与概率 conf")
    out.append(" *      如果 conf < MODEL_THRESHOLD，把 i 改成 MODEL_UNKNOWN_ID")
    out.append(" *      回复就是 MODEL_RESPONSES[i]")
    out.append(" *")
    out.append(" * 4) 算术题：如果 i 正好是 calc 类，别直接查表，")
    out.append(" *      先用 C 版 parse_calc() 解算式（规则照抄 dataset.parse_calc），")
    out.append(" *      解得出来就回算式结果，解不出来才用它表里的兜底回复。")
    out.append(" * ============================================================================ */")
    out.append("")
    out.append("#ifndef __MODEL_WEIGHTS_H")
    out.append("#define __MODEL_WEIGHTS_H")
    out.append("")
    out.append("#define MODEL_FEAT_DIM     %d" % feat_dim)
    out.append("#define MODEL_HIDDEN       %d" % hidden)
    out.append("#define MODEL_NUM_CLASS    %d" % n_class)
    out.append("#define MODEL_HASH_MUL     %d" % hash_mul)
    out.append("#define MODEL_THRESHOLD    %.4ff" % threshold)
    out.append("#define MODEL_TEMPERATURE  %.4ff" % temperature)
    out.append("#define MODEL_UNKNOWN_ID   %d" % unknown_id)
    out.append("#define MODEL_CALC_ID      %d" % (tags.index("calc") if "calc" in tags else -1))
    out.append("")
    out.append("/* 第一层：%d x %d */" % (feat_dim, hidden))
    out.append(fmt_float_array("MODEL_W1", W1))
    out.append("/* 第一层偏置 */")
    out.append(fmt_float_array("MODEL_B1", b1))
    out.append("")
    out.append("/* 第二层：%d x %d */" % (hidden, n_class))
    out.append(fmt_float_array("MODEL_W2", W2))
    out.append("/* 第二层偏置 */")
    out.append(fmt_float_array("MODEL_B2", b2))
    out.append("")
    n_resp = len(responses[0]) if responses else 1
    out.append("/* 每个类别的回复，每类 %d 条，轮换着用（免得每次答得一模一样）。" % n_resp)
    out.append(" * 选哪条：turn %% MODEL_RESP_PER_INTENT，turn 是对话轮数，MCU 端用一个静态计数器就行 */")
    out.append("#define MODEL_RESP_PER_INTENT  %d" % n_resp)
    out.append("static const char *const MODEL_RESPONSES[MODEL_NUM_CLASS][MODEL_RESP_PER_INTENT] = {")
    for i, row in enumerate(responses):
        items = ", ".join('"%s"' % r for r in row)
        out.append("    {%s},    /* %d  %s */" % (items, i, tags[i]))
    out.append("};")
    out.append("")
    out.append("/* 类别名，调试时可以从串口打出来看模型认成了哪一类 */")
    out.append("static const char *const MODEL_TAGS[MODEL_NUM_CLASS] = {")
    for tag in tags:
        out.append('    "%s",' % tag)
    out.append("};")
    out.append("")
    out.append("#endif /* __MODEL_WEIGHTS_H */")
    out.append("")

    text = "\n".join(out)
    with open(HEADER_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

    print("已生成：%s（%.1f KB 文本）" % (HEADER_PATH, len(text) / 1024.0))

    # ---------------- 自检 + 给 M2 留对拍基准 ----------------
    print("\n对拍基准（M2 阶段在板子上跑同样这几句，结果应完全一致）：")
    print("-" * 64)

    for sent in TEST_SENTENCES:
        f = featurize_ref(sent, feat_dim, hash_mul)
        z1 = f @ W1 + b1
        a1 = np.maximum(z1, 0.0)
        z2 = a1 @ W2 + b2
        p = softmax_ref(z2 / temperature)
        cid = int(np.argmax(p))
        conf = float(p[cid])
        if conf < threshold:
            cid = unknown_id

        reply = responses[cid][0]
        if ("calc" in tags) and (cid == tags.index("calc")):
            r = parse_calc_ref(sent)
            # 判成算术题但式子解不出来（哈希碰撞误判），改回"不太懂"更自然
            reply = r if r is not None else responses[unknown_id][0]
        print("  %-10s -> %-10s (%.3f)  回复: %s"
              % (sent, tags[cid], conf, reply))

    # ---------------- M2 的字库需求 ----------------
    used = sorted(set("".join(r for row in responses for r in row)) | set("0123456789+-*/=. "))
    ascii_used = [c for c in used if ord(c) < 128]
    cjk_used = [c for c in used if ord(c) >= 128]
    print("\n" + "=" * 64)
    print("M2 字库需求：回复和算式结果里一共用到 %d 个字符" % len(used))
    print("  非 ASCII（需要 OLED 中文字模）：%d 个" % len(cjk_used))
    print("  " + "".join(cjk_used))
    print("  纯 ASCII（驱动自带字模）：%s" % ("".join(ascii_used) or "无"))
    print("=" * 64)
    print("\n下一步（M2）：把 model_weights.h 拷进 STM32 工程，")
    print("             写 C 版的特征提取 + 前向推理 + parse_calc，再和上面的对拍基准核对。")


# ---- 下面几个函数是 dataset.py / model.py 里逻辑的精简复刻，只给本脚本自检用 ----
DROP_CHARS = set(" \t\r\n\u3000，。！？、；：""''（）《》【】,.!?;:\"'()[]<>_…~@#$%^&")
TYPO_FIX = {"泥嚎": "你好", "尼好": "你好", "在么": "在吗", "蟹蟹": "谢谢",
            "3q": "谢谢", "thx": "谢谢"}
CN_DIGIT = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
            "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def featurize_ref(text, feat_dim, hash_mul):
    """复刻 dataset.featurize（纠正错字、去标点、单字 + 前后 bigram、L2 归一化）。"""
    for wrong, right in TYPO_FIX.items():
        if wrong in text:
            text = text.replace(wrong, right)
    clean = "".join(ch for ch in text if ch not in DROP_CHARS)

    feat = np.zeros(feat_dim, dtype=np.float32)
    codes = [ord(ch) for ch in clean]
    for i, code in enumerate(codes):
        feat[code % feat_dim] += 1.0
        if i > 0:
            feat[(codes[i - 1] * hash_mul + code) % feat_dim] += 1.0
        if i + 1 < len(codes):
            feat[(code * hash_mul + codes[i + 1]) % feat_dim] += 1.0
        if i >= 2:
            tri = ((codes[i - 2] * hash_mul + codes[i - 1]) * hash_mul + code) % feat_dim
            feat[tri] += 0.5

    norm = float(np.linalg.norm(feat))
    if norm > 0.0:
        feat /= norm
    return feat


def softmax_ref(z):
    """复刻 model.softmax（减最大值防溢出）。"""
    z = z - np.max(z)
    e = np.exp(z)
    return e / np.sum(e)


def cn_number_to_int_ref(s):
    if not s:
        return None
    if "十" not in s:
        return CN_DIGIT.get(s) if len(s) == 1 else None
    left, _, right = s.partition("十")
    tens = 1 if left == "" else CN_DIGIT.get(left)
    ones = 0 if right == "" else CN_DIGIT.get(right)
    if tens is None or ones is None:
        return None
    return tens * 10 + ones


def parse_calc_ref(text):
    """复刻 dataset.parse_calc。"""
    s = "".join(ch for ch in text if ch not in DROP_CHARS)
    for cn, sym in (("加上", "+"), ("加", "+"), ("减去", "-"), ("减", "-"),
                    ("乘以", "*"), ("乘", "*"), ("除以", "/"), ("除", "/")):
        s = s.replace(cn, sym)

    out, buf = [], ""
    for ch in s:
        if ch in CN_DIGIT or ch == "十":
            buf += ch
        else:
            if buf:
                v = cn_number_to_int_ref(buf)
                if v is None:
                    return None
                out.append(str(v))
                buf = ""
            out.append(ch)
    if buf:
        v = cn_number_to_int_ref(buf)
        if v is None:
            return None
        out.append(str(v))
    s = "".join(out)

    i, n = 0, len(s)
    while i < n and not s[i].isdigit():
        i += 1
    if i >= n:
        return None
    j = i
    while j < n and s[j].isdigit():
        j += 1
    a_str = s[i:j]
    while j < n and s[j] not in "+-*/":
        j += 1
    if j >= n:
        return None
    op = s[j]
    j += 1
    while j < n and not s[j].isdigit():
        j += 1
    if j >= n:
        return None
    k = j
    while k < n and s[k].isdigit():
        k += 1
    b_str = s[j:k]

    a, b = int(a_str), int(b_str)
    if b == 0 and op == "/":
        return None
    if op == "+":
        r = a + b
    elif op == "-":
        r = a - b
    elif op == "*":
        r = a * b
    else:
        r = a // b if a % b == 0 else round(a / b, 1)
    return "%d%s%d=%s" % (a, op, b, r)


if __name__ == "__main__":
    main()
