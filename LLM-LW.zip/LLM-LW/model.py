# -*- coding: utf-8 -*-
"""
model.py —— 第 2 步：模型本体（两层 MLP，纯 numpy 手写）

这里不借助 PyTorch，用 numpy 把"前向传播 / 反向传播 / 参数更新"亲手写一遍。
看懂这个文件，你就真正理解神经网络是怎么学的了。

================================================================================
【网络结构】

    特征向量 (64 维)
        │
        ├─ z1 = X @ W1 + b1          W1: 64x32   b1: 32      ← 全连接层 1
        ├─ a1 = ReLU(z1)             max(0, z1)              ← 激活函数
        ├─ z2 = a1 @ W2 + b2         W2: 32x15   b2: 15      ← 全连接层 2
        └─ p  = softmax(z2)                                    ← 变成概率

    输出 p 是 15 个类别的概率，加起来等于 1，取最大的那个就是预测结果。

    参数量 = 64*32 + 32 + 32*15 + 15 = 2575 个
    float32 存下来约 10 KB，F103 的 64KB Flash 塞得下（HAL 和字库之后还剩约 45KB）。

【损失函数：交叉熵 + L2 正则】

    L = -(1/N) * Σ log p[i, y[i]]  +  (λ/2) * (ΣW1² + ΣW2²)
        └─ 第一项：让正确答案的概率尽量接近 1
        └─ 第二项：惩罚过大的权重，防止过拟合（数据少的时候特别需要）

【反向传播的推导（关键，慢慢看）】

    先求 softmax + 交叉熵 对 z2 的偏导，这两者合在一起有个非常漂亮的结果：

        ∂L/∂z2 = (p - onehot(y)) / N

    也就是说"预测概率 - 真实标签"，误差直接就是梯度。然后按链式法则往回传：

        ∂L/∂W2 = a1ᵀ · ∂L/∂z2 + λ·W2
        ∂L/∂b2 = Σ ∂L/∂z2                      （对样本这一维求和）
        ∂L/∂a1 = ∂L/∂z2 · W2ᵀ
        ∂L/∂z1 = ∂L/∂a1 ⊙ (z1 > 0)              ← ReLU 的导数：正数处为 1，否则 0
        ∂L/∂W1 = Xᵀ · ∂L/∂z1 + λ·W1
        ∂L/∂b1 = Σ ∂L/∂z1

    最后沿梯度反方向走一小步（学习率 lr）：

        W ← W - lr · ∂L/∂W
================================================================================
"""

import numpy as np


# ============================== 基础函数 ==============================
def softmax(z):
    """
    softmax：把一排实数变成"加起来等于 1"的概率。

        softmax(z_i) = exp(z_i) / Σ exp(z_j)

    这里先减去每行的最大值再取 exp，纯粹是为了防止 exp 溢出（数值稳定技巧），
    数学结果完全一样。
    """
    z = z - np.max(z, axis=1, keepdims=True)
    e = np.exp(z)
    return e / np.sum(e, axis=1, keepdims=True)


def relu(z):
    """ReLU 激活：负数变 0，正数不变。"""
    return np.maximum(z, 0.0)


def one_hot(y, n_class):
    """把类别编号变成 one-hot 向量，例如 2 -> [0,0,1,0,...]。"""
    out = np.zeros((y.shape[0], n_class), dtype=np.float32)
    out[np.arange(y.shape[0]), y] = 1.0
    return out


def cross_entropy(p, y):
    """交叉熵损失：只看"正确答案那个概率"有多小。"""
    n = p.shape[0]
    # clip 一下，防止 log(0) 变成 -inf
    correct = np.clip(p[np.arange(n), y], 1e-9, 1.0)
    return float(-np.mean(np.log(correct)))


# ============================== 模型 ==============================
class MLP:
    """
    两层全连接网络。

    参数:
        n_in     -- 输入维度（就是 dataset.FEAT_DIM）
        n_hidden -- 隐藏层神经元个数
        n_out    -- 类别数
        seed     -- 随机种子，固定住可以复现同样的训练结果
    """

    def __init__(self, n_in, n_hidden, n_out, seed=0):
        rng = np.random.default_rng(seed)

        # He 初始化：配合 ReLU 用，标准差取 sqrt(2/输入维度)。
        # 全零初始化会让所有神经元学到一样的东西（对称性无法打破），所以必须随机。
        self.W1 = rng.normal(0.0, np.sqrt(2.0 / n_in), (n_in, n_hidden)).astype(np.float32)
        self.b1 = np.zeros(n_hidden, dtype=np.float32)
        self.W2 = rng.normal(0.0, np.sqrt(1.0 / n_hidden), (n_hidden, n_out)).astype(np.float32)
        self.b2 = np.zeros(n_out, dtype=np.float32)

        # 动量项：把上一步的梯度方向也带上一点，收敛更稳、更快
        self.vW1 = np.zeros_like(self.W1)
        self.vb1 = np.zeros_like(self.b1)
        self.vW2 = np.zeros_like(self.W2)
        self.vb2 = np.zeros_like(self.b2)

    # ------------------------- 前向传播 -------------------------
    def forward(self, X):
        """
        前向：输入一批样本，输出每类的概率。

        中间结果（z1/a1/z2）都存下来，反向传播时要用。

        参数: X -- shape=(N, n_in)
        返回: p -- shape=(N, n_out)，每行是一个概率分布
        """
        self.X = X
        self.z1 = X @ self.W1 + self.b1          # (N, n_hidden)
        self.a1 = relu(self.z1)                  # (N, n_hidden)
        self.z2 = self.a1 @ self.W2 + self.b2    # (N, n_out)
        self.p = softmax(self.z2)                # (N, n_out)
        return self.p

    # ------------------------- 反向传播 + 更新 -------------------------
    def backward(self, y, lr=0.5, l2=1e-4, momentum=0.9, sample_weight=None):
        """
        反向：算出每个参数的梯度，然后沿梯度反方向更新一步。

        参数:
            y             -- 真实类别编号，shape=(N,)
            lr            -- 学习率（步子迈多大）
            l2            -- L2 正则强度
            momentum      -- 动量系数
            sample_weight -- 每个样本的权重，shape=(N,)；用来平衡样本数差很多的类别。
                             比如 unknown 类样本少，就给它更高的权重，不然模型会偏向
                             那些样本多的类别。None 表示所有样本一视同仁。
        """
        n = self.X.shape[0]
        n_out = self.W2.shape[1]

        # ---- 输出层的误差 ----
        # softmax + 交叉熵 的梯度就是这么简洁：预测值减真实值，再除以样本数
        dz2 = self.p - one_hot(y, n_out)                  # (N, n_out)
        if sample_weight is not None:
            dz2 = dz2 * sample_weight.reshape(-1, 1)      # 逐样本加权
        dz2 = dz2 / n

        dW2 = self.a1.T @ dz2 + l2 * self.W2              # (n_hidden, n_out)
        db2 = np.sum(dz2, axis=0)                         # (n_out,)

        # ---- 误差往回传到隐藏层 ----
        da1 = dz2 @ self.W2.T                             # (N, n_hidden)
        dz1 = da1 * (self.z1 > 0.0)                       # ReLU 的导数

        dW1 = self.X.T @ dz1 + l2 * self.W1               # (n_in, n_hidden)
        db1 = np.sum(dz1, axis=0)                         # (n_hidden,)

        # ---- 带动量更新参数 ----
        self.vW1 = momentum * self.vW1 - lr * dW1
        self.vb1 = momentum * self.vb1 - lr * db1
        self.vW2 = momentum * self.vW2 - lr * dW2
        self.vb2 = momentum * self.vb2 - lr * db2

        self.W1 += self.vW1
        self.b1 += self.vb1
        self.W2 += self.vW2
        self.b2 += self.vb2

    # ------------------------- 预测 -------------------------
    def logits(self, X):
        """
        返回 softmax 之前的原始得分（logits）。

        做"温度缩放"时要用：模型输出的概率通常过自信（明明是瞎猜，也敢给 0.9），
        把 logits 除以一个大于 1 的温度再 softmax，概率就被压平了。
        这样"其实不懂"的句子概率不会虚高，阈值才拦得住。
        """
        z1 = X @ self.W1 + self.b1
        a1 = relu(z1)
        return a1 @ self.W2 + self.b2

    def predict_proba(self, X):
        """返回每类的概率（不改动训练状态，所以借用一份临时前向）。"""
        return softmax(self.logits(X))

    def predict(self, X):
        """返回预测的类别编号，shape=(N,)。"""
        return np.argmax(self.predict_proba(X), axis=1)

    # ------------------------- 保存 / 加载 -------------------------
    def save(self, path, tags, responses, feat_dim, hidden, threshold=0.0,
             temperature=1.0):
        """
        保存权重和元信息到一个 .npz 文件。

        元信息（tags/responses/维度/阈值/温度）也一起存，
        这样导出和推理时不用再猜结构。
        """
        np.savez(
            path,
            W1=self.W1, b1=self.b1, W2=self.W2, b2=self.b2,
            tags=np.array(tags), responses=np.array(responses),
            feat_dim=np.int32(feat_dim), hidden=np.int32(hidden),
            hash_mul=np.int32(31), threshold=np.float32(threshold),
            temperature=np.float32(temperature),
        )
