#ifndef __BT_FIFO_H
#define __BT_FIFO_H

#include "main.h"
#include <stdint.h>

/* FIFO缓冲区大小。
 * 注意：刷新一次 OLED 是软件 I2C，主循环会被阻塞十几毫秒，
 * 这段时间收到的串口数据全靠这个缓冲区兜住；一帧最长约 91 字节
 * （30 个汉字 × 3 字节 + 结束符），再加上下一帧的开头，所以给到 256 字节。*/
#define BT_FIFO_BUF_SIZE    256U

/**
 * @brief  往FIFO存入1字节，中断回调里面调用，执行极快
 * @param  byte：待存入字节
 * @retval 无
 */
void BT_FIFO_Put(uint8_t byte);

/**
 * @brief 从FIFO取出1字节，主while(1)循环调用
 * @retval 返回字节；0xFF代表FIFO为空，没有数据
 */
uint8_t BT_FIFO_Get(void);

/**
 * @brief  判断FIFO是否为空
 * @retval 1：空；0：还有数据
 * @note   因为 0xFF 是合法的数据字节，不能用 BT_FIFO_Get 的返回值当空标志，
 *         要判断空就用这个函数
 */
uint8_t BT_FIFO_IsEmpty(void);
/**
 * @brief 清空FIFO缓冲区
 * @retval 无
 */
void BT_FIFO_Clear(void);

#endif
