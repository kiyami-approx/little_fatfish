#ifndef __MODEL_H_
#define __MODEL_H_

#include "main.h"

/**
  * @brief  给一句话生成回复（模型推理 + 算术解析）
  * @param  text 用户输入，UTF-8 字符串
  * @retval 回复文本（UTF-8，静态存储，可以直接喂给 OLED 或串口）
  * @note   内部会自动记住上一句输入作为对话上下文，所以连续调用就能连贯对话
  */
const char *LLM_Reply(const char *text);

/**
  * @brief  清空对话状态（上一句输入、回复轮次）
  * @retval 无
  */
void LLM_Reset(void);

#endif
