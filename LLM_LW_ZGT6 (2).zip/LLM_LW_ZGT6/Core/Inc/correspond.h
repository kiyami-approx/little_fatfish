#ifndef __CORRESPOND_H_
#define __CORRESPOND_H_

#include "main.h"
#include "OLED.h"

#define BT_RX_BUF_LEN   100U

typedef enum
{
	CLEAR_GO,
	FREE
}Clear_State;


typedef enum
{
	SHOW_SWITCH,
	SHOW_START,
	SHOW_SWITCH_READY,

}Show_State;

extern char Serial_RxPacket[BT_RX_BUF_LEN];

extern Clear_State Clear_flag;
extern uint8_t bt_rx_idx;
void BT_UART(uint8_t ch);
void LLM_Show(void);







#endif
