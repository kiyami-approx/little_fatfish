#include "OLED.h"
#include "OLED_Font.h"

/* ============================== 引脚配置 ============================== */
/* 修改引脚时只需改动下面的端口与引脚宏，并同步修改时钟使能宏            */
#define OLED_GPIO_PORT          GPIOB
#define OLED_GPIO_CLK_ENABLE()  __HAL_RCC_GPIOB_CLK_ENABLE()

#define OLED_SCL_PIN            GPIO_PIN_10     /* 时钟线 SCL -> PB10 */
#define OLED_SDA_PIN            GPIO_PIN_11     /* 数据线 SDA -> PB11 */

/* 供电方式二选一：
 *   1 = 用 PB7/PB6 两个 GPIO 给屏供电（需要这两个脚也引出来了）
 *   0 = 屏的 VCC/GND 直接接板子的 3.3V/GND，驱动完全不占用这两个引脚 */
#define OLED_POWER_BY_GPIO      1

#define OLED_VCC_PIN            GPIO_PIN_7      /* 用 GPIO 给模块供电：VCC */
#define OLED_GND_PIN            GPIO_PIN_6      /* 用 GPIO 给模块供电：GND */

/* 写 SCL / SDA 电平：x 非 0 输出高电平，x 为 0 输出低电平 */
#define OLED_W_SCL(x)   HAL_GPIO_WritePin(OLED_GPIO_PORT, OLED_SCL_PIN, (x) ? GPIO_PIN_SET : GPIO_PIN_RESET)
#define OLED_W_SDA(x)   HAL_GPIO_WritePin(OLED_GPIO_PORT, OLED_SDA_PIN, (x) ? GPIO_PIN_SET : GPIO_PIN_RESET)

/* I2C 从机地址（0x3C << 1） */
#define OLED_I2C_ADDRESS        0x78

/* ============================ GPIO 初始化 ============================ */
/**
  * @brief  切换 SDA 的方向
  * @param  Output 1 = 推挽输出（主机驱动数据）；0 = 上拉输入（放开总线读应答）
  * @retval 无
  * @note   这套"推挽驱动 + 读应答时放开 SDA"的写法，最早是在 STM32F1 上逼出来的：
  *         F1 的开漏输出模式下芯片没有内部上拉，HAL 的 GPIO_PULLUP 在输出模式
  *         下会被直接忽略，于是屏模块只要不自带上拉电阻，SCL/SDA 在"写 1"的时候就
  *         变成悬空，总线完全没法工作（典型现象：I2C 扫描时拔掉屏反而所有地址都应答）。
  *         现在换到 STM32F4，F4 的开漏输出是带内部上拉的，用标准开漏写法也能跑，
  *         但这里保持推挽不变，好处是不依赖屏模块有没有上拉电阻，
  *         以后换任何一块 I2C 屏都不会再因为上拉的问题点不亮。
  *         当然，在 SCL/SDA 上各接一个 4.7k 上拉电阻到 3.3V 才是最规范的做法。
  */
static void OLED_SDA_Mode(uint8_t Output)
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};

	GPIO_InitStructure.Pin = OLED_SDA_PIN;
	GPIO_InitStructure.Mode = Output ? GPIO_MODE_OUTPUT_PP : GPIO_MODE_INPUT;
	GPIO_InitStructure.Pull = Output ? GPIO_NOPULL : GPIO_PULLUP;	//上拉只在输入模式下才有效
	GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(OLED_GPIO_PORT, &GPIO_InitStructure);
}

/**
  * @brief  软件 I2C 引脚初始化
  * @param  无
  * @retval 无
  * @note   SCL、SDA 都配成推挽输出（理由见 OLED_SDA_Mode 的说明），
  *         SCL 用 PB10、SDA 用 PB11；如果 OLED_POWER_BY_GPIO = 1，
  *         再把 PB7、PB6 配成推挽输出给屏供电。
  */
void OLED_I2C_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};

	OLED_GPIO_CLK_ENABLE();								//使能 GPIO 时钟

	/* SCL、SDA：推挽输出，不依赖外部上拉 */
	GPIO_InitStructure.Pin = OLED_SCL_PIN | OLED_SDA_PIN;
	GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;		//推挽输出模式
	GPIO_InitStructure.Pull = GPIO_NOPULL;
	GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(OLED_GPIO_PORT, &GPIO_InitStructure);

	OLED_W_SCL(1);										//空闲时 SCL、SDA 均为高电平
	OLED_W_SDA(1);

#if OLED_POWER_BY_GPIO
	/* 用 GPIO 口供电：VCC、GND 为推挽输出 */
	GPIO_InitStructure.Pin = OLED_VCC_PIN | OLED_GND_PIN;
	GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;		//推挽输出
	GPIO_InitStructure.Pull = GPIO_NOPULL;
	GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(OLED_GPIO_PORT, &GPIO_InitStructure);

	HAL_GPIO_WritePin(OLED_GPIO_PORT, OLED_VCC_PIN, GPIO_PIN_SET);		//VCC
	HAL_GPIO_WritePin(OLED_GPIO_PORT, OLED_GND_PIN, GPIO_PIN_RESET);	//GND
#endif
}

/**
  * @brief  I2C开始
  * @param  无
  * @retval 无
  */
void OLED_I2C_Start(void)
{
	OLED_W_SDA(1);
	OLED_W_SCL(1);
	OLED_W_SDA(0);
	OLED_W_SCL(0);
}

/**
  * @brief  I2C停止
  * @param  无
  * @retval 无
  */
void OLED_I2C_Stop(void)
{
	OLED_W_SDA(0);
	OLED_W_SCL(1);
	OLED_W_SDA(1);
}

/**
  * @brief  I2C发送一个字节
  * @param  Byte 要发送的一个字节
  * @retval 无
  */
void OLED_I2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		OLED_W_SDA(Byte & (0x80 >> i));
		OLED_W_SCL(1);
		OLED_W_SCL(0);
	}

	/* 第 9 个时钟是应答位。这里必须先放开 SDA 再把 SCL 拉高：
	   SDA 现在是推挽输出，如果继续保持推挽高电平，而从机这一拍想把 SDA
	   拉低来表示应答，两边就顶在一起了（会灌大电流）。切成上拉输入等于放开总线。
	   原来的代码不检查应答，这里同样不检查，只是把电气时序做对。 */
	OLED_SDA_Mode(0);
	OLED_W_SCL(1);	//额外的一个时钟，不处理应答信号
	OLED_W_SCL(0);
	OLED_SDA_Mode(1);
}

/**
  * @brief  OLED写命令
  * @param  Command 要写入的命令
  * @retval 无
  */
void OLED_WriteCommand(uint8_t Command)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(OLED_I2C_ADDRESS);	//从机地址
	OLED_I2C_SendByte(0x00);				//写命令
	OLED_I2C_SendByte(Command); 
	OLED_I2C_Stop();
}

/**
  * @brief  OLED写数据
  * @param  Data 要写入的数据
  * @retval 无
  */
void OLED_WriteData(uint8_t Data)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(OLED_I2C_ADDRESS);	//从机地址
	OLED_I2C_SendByte(0x40);				//写数据
	OLED_I2C_SendByte(Data);
	OLED_I2C_Stop();
}

/**
  * @brief  OLED设置光标位置
  * @param  Y 以左上角为原点，向下方向的坐标，范围：0~7
  * @param  X 以左上角为原点，向右方向的坐标，范围：0~127
  * @retval 无
  */
void OLED_SetCursor(uint8_t Y, uint8_t X)
{
	OLED_WriteCommand(0xB0 | Y);					//设置Y位置
	OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));	//设置X位置高4位
	OLED_WriteCommand(0x00 | (X & 0x0F));			//设置X位置低4位
}

/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Clear(void)
{  
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		OLED_SetCursor(j, 0);
		for(i = 0; i < 128; i++)
		{
			OLED_WriteData(0x00);
		}
	}
}

/**
  * @brief  OLED显示一个字符
  * @param  Line 行位置，范围：1~4
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{      	
	uint8_t i;
	OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);		//设置光标位置在上半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i]);			//显示上半部分内容
	}
	OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);	//设置光标位置在下半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i + 8]);		//显示下半部分内容
	}
}

/**
  * @brief  OLED显示字符串
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar(Line, Column + i, String[i]);
	}
}

/**
  * @brief  OLED次方函数
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

/**
  * @brief  OLED显示数字（十进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~4294967295
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十进制，带符号数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：-2147483648~2147483647
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十六进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~0xFFFFFFFF
  * @param  Length 要显示数字的长度，范围：1~8
  * @retval 无
  */
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i, SingleNumber;
	for (i = 0; i < Length; i++)							
	{
		SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
		if (SingleNumber < 10)
		{
			OLED_ShowChar(Line, Column + i, SingleNumber + '0');
		}
		else
		{
			OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A');
		}
	}
}

/**
  * @brief  OLED显示数字（二进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~1111 1111 1111 1111
  * @param  Length 要显示数字的长度，范围：1~16
  * @retval 无
  */
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
	}
}

/**
  * @brief  OLED初始化
  * @param  无
  * @retval 无
  * @note   需在 HAL_Init() 之后调用（内部用 HAL_Delay 做上电延时）
  */
void OLED_Init(void)
{
	/* ⚠️ 顺序很关键：这个屏是靠 PB7 供电的，
	 *    必须先 OLED_I2C_Init() 把电供上，再去等它复位稳定。
	 *    反过来写（先延时、后供电）等的是一个还没通电的屏，
	 *    屏内部复位没走完就开始发命令，画面就会一直不亮。 */
	OLED_I2C_Init();			//先把引脚配好、给屏供电

	HAL_Delay(100);				//上电延时，等待 OLED 内部复位完成
	
	OLED_WriteCommand(0xAE);	//关闭显示
	
	OLED_WriteCommand(0xD5);	//设置显示时钟分频比/振荡器频率
	OLED_WriteCommand(0x80);
	
	OLED_WriteCommand(0xA8);	//设置多路复用率
	OLED_WriteCommand(0x3F);
	
	OLED_WriteCommand(0xD3);	//设置显示偏移
	OLED_WriteCommand(0x00);
	
	OLED_WriteCommand(0x40);	//设置显示开始行
	
	OLED_WriteCommand(0xA1);	//设置左右方向，0xA1正常 0xA0左右反置
	
	OLED_WriteCommand(0xC8);	//设置上下方向，0xC8正常 0xC0上下反置

	OLED_WriteCommand(0xDA);	//设置COM引脚硬件配置
	OLED_WriteCommand(0x12);
	
	OLED_WriteCommand(0x81);	//设置对比度控制
	OLED_WriteCommand(0xCF);

	OLED_WriteCommand(0xD9);	//设置预充电周期
	OLED_WriteCommand(0xF1);

	OLED_WriteCommand(0xDB);	//设置VCOMH取消选择级别
	OLED_WriteCommand(0x30);

	OLED_WriteCommand(0xA4);	//设置整个显示打开/关闭

	OLED_WriteCommand(0xA6);	//设置正常/倒转显示

	OLED_WriteCommand(0x8D);	//设置充电泵
	OLED_WriteCommand(0x14);

	OLED_WriteCommand(0xAF);	//开启显示
		
	OLED_Clear();				//OLED清屏
}

/* ========================== UTF-8 中文显示支持 ==========================
 * 汉字字模是 16x16 的，在 OLED 上占 2 页（Page）×16 列，
 * 也就是占 2 个 ASCII 字符的宽度，所以下面统一用“列”来定位：
 * Column = 1 是屏幕最左边，Column = 16 是最右边，一个汉字占 Column 和 Column+1。
 * ====================================================================== */

/**
  * @brief  从 UTF-8 字节流里解出一个 Unicode 码点
  * @param  String UTF-8 字符串
  * @param  Index  当前字节下标；函数返回时会被推进到下一个字符的起始字节
  * @retval 解码出的 Unicode 码点；非法字节返回 '?'，并保证 Index 至少前进 1
  * @note   只支持 BMP（码点 <= 0xFFFF），4 字节的 emoji 一律当成 '?' 处理
  */
static uint16_t OLED_UTF8_Decode(const char *String, uint8_t *Index)
{
	uint8_t i = *Index;
	uint8_t B0 = (uint8_t)String[i];
	uint8_t n, k;
	uint16_t Code;

	if (B0 < 0x80U)							//0xxxxxxx：单字节，就是 ASCII
	{
		*Index = i + 1U;
		return B0;
	}
	else if ((B0 & 0xE0U) == 0xC0U)			//110xxxxx：双字节（拉丁扩展等）
	{
		n = 2U;
		Code = B0 & 0x1FU;
	}
	else if ((B0 & 0xF0U) == 0xE0U)			//1110xxxx：三字节（常用汉字都在这里）
	{
		n = 3U;
		Code = B0 & 0x0FU;
	}
	else if ((B0 & 0xF8U) == 0xF0U)			//11110xxx：四字节（emoji 等）
	{
		n = 4U;
		Code = B0 & 0x07U;
	}
	else									//10xxxxxx 或 11111xxx：非法首字节
	{
		*Index = i + 1U;
		return (uint16_t)'?';
	}

	//逐个检查后续的续字节，任何一个不合法就只跳过一个字节，避免卡死
	for (k = 1U; k < n; k++)
	{
		uint8_t Bk = (uint8_t)String[i + k];
		if ((Bk & 0xC0U) != 0x80U)			//不是 10xxxxxx，说明这串 UTF-8 被截断了
		{
			*Index = i + 1U;
			return (uint16_t)'?';
		}
		Code = (uint16_t)((Code << 6) | (Bk & 0x3FU));
	}

	*Index = (uint8_t)(i + n);

	if ((n == 4U) || (Code == 0U))			//超出 BMP 或非法零码点，不显示
	{
		return (uint16_t)'?';
	}
	return Code;
}

/**
  * @brief  在字库中按 Unicode 码点查找字模
  * @param  Code 汉字 / 全角标点的 Unicode 码点
  * @retval 指向 32 字节字模的指针；没有这个字时返回 0
  * @note   字模表按码点升序排列，这里用二分查找
  */
static const uint8_t *OLED_ChineseFontFind(uint16_t Code)
{
	uint16_t Left = 0U;
	uint16_t Right = (uint16_t)(OLED_CHINESE_FONT_NUM - 1U);

	while (Left <= Right)
	{
		uint16_t Mid = (uint16_t)((Left + Right) >> 1);

		if (OLED_ChineseFont[Mid].Code == Code)
		{
			return OLED_ChineseFont[Mid].Data;
		}
		else if (Code < OLED_ChineseFont[Mid].Code)
		{
			if (Mid == 0U)					//防止 Right 下溢变成 0xFFFF
			{
				break;
			}
			Right = (uint16_t)(Mid - 1U);
		}
		else
		{
			Left = (uint16_t)(Mid + 1U);
		}
	}
	return 0;
}

/**
  * @brief  OLED显示一个 16x16 的汉字
  * @param  Line   行位置，范围：1~4
  * @param  Column 列位置（以 8 像素为一列），范围：1~15
  * @param  Code   汉字的 Unicode 码点
  * @retval 无
  */
static void OLED_ShowChineseChar(uint8_t Line, uint8_t Column, uint16_t Code)
{
	const uint8_t *pData;
	uint8_t i;
	uint8_t X = (uint8_t)((Column - 1U) * 8U);	//列坐标换算成屏幕像素横坐标

	if ((Line < 1U) || (Line > 4U) || (Column < 1U) || (Column > 15U))
	{
		return;									//越界直接不显示，防止写到屏幕外面
	}

	pData = OLED_ChineseFontFind(Code);
	if (pData == 0)								//字库里没有这个字
	{
		OLED_ShowChar(Line, Column, '?');		//用 ? 顶替，同样占 2 列宽
		return;
	}

	//上半部分：写到第 (Line-1)*2 页
	OLED_SetCursor((uint8_t)((Line - 1U) * 2U), X);
	for (i = 0U; i < 16U; i++)
	{
		OLED_WriteData(pData[i]);
	}

	//下半部分：写到第 (Line-1)*2+1 页
	OLED_SetCursor((uint8_t)((Line - 1U) * 2U + 1U), X);
	for (i = 0U; i < 16U; i++)
	{
		OLED_WriteData(pData[16U + i]);
	}
}

/**
  * @brief  OLED显示字符串（支持 UTF-8 中文，可与 ASCII 混排）
  * @param  Line   起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16（一个汉字占 2 列，一个 ASCII 字符占 1 列）
  * @param  String 要显示的字符串，源文件必须是 UTF-8 编码
  * @retval 无
  * @note   用 HAL 库时源文件默认就是 UTF-8，直接写中文常量即可；
  *         放不下的部分会自动换到下一行，4 行都写满就停止。
  */
void OLED_ChineseShowString(uint8_t Line, uint8_t Column, char *String)
{
	uint8_t i = 0U;

	if ((Line < 1U) || (Line > 4U) || (Column < 1U) || (Column > 16U))
	{
		return;
	}

	while (String[i] != '\0')
	{
		uint16_t Code = OLED_UTF8_Decode(String, &i);

		if (Code < 0x80U)						//ASCII 可见字符，占 1 列
		{
			OLED_ShowChar(Line, Column, (char)Code);
			Column++;
		}
		else									//汉字 / 全角符号，占 2 列
		{
			if (Column > 15U)					//这一行只剩 1 列，放不下汉字，先换行
			{
				Column = 1U;
				Line++;
				if (Line > 4U)
				{
					break;
				}
			}
			OLED_ShowChineseChar(Line, Column, Code);
			Column += 2U;
		}

		if (Column > 16U)						//一行写满，换到下一行
		{
			Column = 1U;
			Line++;
			if (Line > 4U)
			{
				break;
			}
		}
	}
}
