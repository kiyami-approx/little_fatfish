#include "correspond.h"
#include "model.h"
#include "usart.h"
#include <string.h>

/* 16 个空格：字模全是 0，写上去等于把这一行擦干净 */
#define BT_LINE_BLANK   "                "

char Serial_RxPacket[BT_RX_BUF_LEN];			//电脑发来UTF-8格式的中文
static char Serial_ShowPacket[BT_RX_BUF_LEN];	//显示用的快照，避免原缓冲被清掉后屏幕上就没内容了
uint8_t bt_rx_idx = 0U;
static uint8_t out_flag = 0U;					//1：当前这句输入超长，被截断了
static uint8_t show_dirty = 1U;					//1：屏幕需要重画（上电先画一次欢迎语）
static Show_State Show_flag = SHOW_START;
Clear_State Clear_flag = FREE;					//必须显式初始化，否则默认是 0（CLEAR_GO），上电就会误清一次

/**
  * @brief  往串口回一句，末尾带换行
  * @param  s 要发送的字符串（UTF-8）
  * @retval 无
  * @note   这是阻塞发送，只能在主循环里调用，别在中断回调里用。
  *         115200 波特率下发 20 个字节大约 1.7ms，比刷一次 OLED 快得多。
  */
static void BT_SendString(const char *s)
{
	HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 500U);
	HAL_UART_Transmit(&huart1, (uint8_t *)"\r\n", 2U, 100U);
}

/**
  * @brief  处理串口收到的一个字节，攒够一句（遇到 '\n'）就交给 LLM_Show 处理
  * @param  ch 收到的字节
  * @retval 无
  */
void BT_UART(uint8_t ch)
{
	/* 串口助手的换行一般是 "\r\n"，'\r' 直接丢掉，别让它混进要显示的内容里 */
	if (ch == '\r')
	{
		return;
	}

	if (ch == '\n')								//一整句收完了
	{
		Serial_RxPacket[bt_rx_idx] = '\0';		//补上字符串结束符
		out_flag = 0U;
		Show_flag = SHOW_SWITCH;
		show_dirty = 1U;
		Clear_flag = CLEAR_GO;					//通知主循环，这句处理完了可以清缓冲
		return;
	}

	if (bt_rx_idx >= (BT_RX_BUF_LEN - 1U))		//缓冲满了还没等到换行，说明这句太长
	{
		Serial_RxPacket[BT_RX_BUF_LEN - 1U] = '\0';	//强制截断，防止后面按字符串读时越界
		out_flag = 1U;
		Show_flag = SHOW_SWITCH;
		show_dirty = 1U;
		Clear_flag = CLEAR_GO;
		return;
	}

	Serial_RxPacket[bt_rx_idx++] = (char)ch;

	if (bt_rx_idx == 1U)						//这是本句的第一个字节
	{
		out_flag = 0U;
		Show_flag = SHOW_SWITCH_READY;			//先显示“思考中”
		show_dirty = 1U;
	}
}

/**
  * @brief  刷新 OLED 显示，并驱动一轮对话
  * @retval 无
  * @note   只有内容真的变了（show_dirty 置位）才刷屏。OLED 是软件 I2C，
  *         全屏刷一次要十几毫秒，放在 while(1) 里无条件刷会把串口接收拖垮。
  *
  *         屏幕布局：
  *           第 1 行：标题
  *           第 2 行：用户说了什么
  *           第 3 行：小肥鱼的回复（太长会自动换到第 4 行）
  */
void LLM_Show(void)
{
	if (show_dirty == 0U)
	{
		return;
	}
	show_dirty = 0U;

	/* 先把 2~4 行擦干净，防止这次的回复比上次短，后面残留上一次的尾巴 */
	OLED_ShowString(1, 1, BT_LINE_BLANK);		//这个是我加的你不要删
	OLED_ShowString(2, 1, BT_LINE_BLANK);
	OLED_ShowString(3, 1, BT_LINE_BLANK);
	OLED_ShowString(4, 1, BT_LINE_BLANK);

	if (Show_flag == SHOW_START)
	{
		/* 128 像素宽一行最多放 8 个汉字，所以拆成两行 */
		OLED_ChineseShowString(1, 1, "这里是小肥鱼");
		OLED_ChineseShowString(2, 1, "说点什么吧");
	}
	else if (Show_flag == SHOW_SWITCH_READY)
	{
		OLED_ChineseShowString(2, 1, "思考中");
	}
	else if (Show_flag == SHOW_SWITCH)
	{
		memcpy(Serial_ShowPacket, Serial_RxPacket, BT_RX_BUF_LEN);

		if (out_flag == 1U)
		{
			OLED_ChineseShowString(2, 1, "输入超出允许长度");
		}
		else
		{
			const char *reply;

			/* ① 把用户说的先显示出来 */
			OLED_ChineseShowString(2, 1, Serial_ShowPacket);

			/* ② 让小肥鱼想一句（模型推理 + 算术解析都在这里面） */
			reply = LLM_Reply(Serial_ShowPacket);

			/* ③ 显示在第 3 行，同时从串口回给电脑，这样串口助手里也能对话 */
			OLED_ChineseShowString(3, 1, (char *)reply);
			BT_SendString(reply);
		}
	}
}
