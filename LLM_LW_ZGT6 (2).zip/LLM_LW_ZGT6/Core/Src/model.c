#include "model.h"
#include "model_weights.h"
#include <string.h>
#include <math.h>

/* ============================================================================
 * 小肥鱼的大脑：把 PC 上训练好的那套逻辑，在单片机上一比一复刻出来
 *
 * 四步，顺序不能乱，公式也不能改（改了就和 PC 端对不上了）：
 *
 *   ① 归一化    UTF-8 解码成码点 -> 纠正常见错字 -> 丢掉空格和标点
 *   ② 特征提取  单字 + 前邻词组 + 后邻词组 + 三字组合，共 1024 维，最后 L2 归一化
 *               再叠加上一句的特征（权重 0.35）当对话上下文
 *   ③ 前向推理  z1 = feat*W1 + b1 -> ReLU -> z2 = h*W2 + b2 -> softmax(z2/温度)
 *   ④ 判决      置信度低于阈值就改判 unknown；判成算术题就交给 parse_calc 真去算
 *
 * ⚠️ 所有工作数组都是 static 的，绝对不能写成函数里的局部数组：
 *    特征向量一个人就 1024*4 = 4KB，而这个工程的栈总共才 1KB，放栈上必挂。
 * ========================================================================== */

/* ---- 和 dataset.py 里必须保持一致的常数 ---- */
#define CONTEXT_W        0.35f    /* 上一句特征占的权重 */
#define SINGLE_CHAR_W    1.0f     /* 单字特征权重 */
#define TRIGRAM_W        0.5f     /* 三字组合权重 */

#define LLM_MAX_CODES    128      /* 一句话最多多少个字符（码点） */
#define LLM_CALC_BUF     32       /* 算式结果字符串的缓冲 */

/* ---- 工作区（全部放 bss 段，不占栈）---- */
static float    g_feat[MODEL_FEAT_DIM];
static float    g_hidden[MODEL_HIDDEN];
static float    g_logits[MODEL_NUM_CLASS];
static uint16_t g_cur[LLM_MAX_CODES];
static uint16_t g_prev[LLM_MAX_CODES];
static uint16_t g_tmp[LLM_MAX_CODES];
static uint8_t  g_prev_len = 0U;
static uint32_t g_turn = 0U;
static char     g_calc_buf[LLM_CALC_BUF];
static char     g_reply[192];             /* 回复缓冲区（给算术结果用） */

/* ---- 归一化时要丢掉的字符（和 dataset.py 的 DROP_CHARS 一一对应）----
 * 注意 + - * / = 这几个**不能**丢，它们是算术题的关键信息 */
static const uint16_t DROP_CODES[] = {
    0x0020, 0x0009, 0x000A, 0x000D, 0x3000,             /* 空白 */
    0xFF0C, 0x3002, 0xFF01, 0xFF1F, 0x3001,             /* ，。！？、 */
    0xFF1B, 0xFF1A, 0x201C, 0x201D, 0x2018, 0x2019,     /* ；：“”‘’ */
    0xFF08, 0xFF09, 0x300A, 0x300B, 0x3010, 0x3011,     /* （）《》【】 */
    0x002C, 0x002E, 0x0021, 0x003F, 0x003B, 0x003A,     /* ,.!?;: */
    0x0022, 0x0027, 0x0028, 0x0029, 0x005B, 0x005D,     /* "'()[] */
    0x003C, 0x003E, 0x005F, 0x2026, 0x007E,             /* <>_…~ */
    0x0040, 0x0023, 0x0024, 0x0025, 0x005E, 0x0026,     /* @#$%^& */
    0x002A, 0x002B, 0x003D, 0x007C, 0x005C,             /* 注意：这几个我们也丢 */
};

/* 常见错字/简写纠正（和 dataset.py 的 TYPO_FIX 一致） */
typedef struct
{
    const char *wrong;
    const char *right;
} TypoFix;

static const TypoFix TYPO_FIX[] = {
    {"泥嚎", "你好"}, {"尼好", "你好"}, {"在么", "在吗"},
    {"蟹蟹", "谢谢"}, {"3q", "谢谢"},   {"thx", "谢谢"},
};

#define TYPO_FIX_NUM  (sizeof(TYPO_FIX) / sizeof(TYPO_FIX[0]))

/* 汉字数字（和 dataset.py 的 CN_DIGIT 一致） */
static const uint16_t CN_DIGIT_CODE[] = {
    0x96F6, 0x4E00, 0x4E8C, 0x4E24, 0x4E09,   /* 零 一 二 两 三 */
    0x56DB, 0x4E94, 0x516D, 0x4E03, 0x516B,   /* 四 五 六 七 八 */
    0x4E5D,                                    /* 九 */
};
static const uint8_t CN_DIGIT_VALUE[] = { 0, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9 };
#define CN_DIGIT_NUM  (sizeof(CN_DIGIT_CODE) / sizeof(CN_DIGIT_CODE[0]))

/* ============================== UTF-8 解码 ============================== */
/**
  * @brief  把 UTF-8 字符串解码成 Unicode 码点序列
  * @param  s     输入字符串
  * @param  out   输出码点数组
  * @param  max_n 最多解出多少个
  * @retval 实际解出的码点数
  * @note   遇到非法/被截断的序列返回 '?' 并且只前进一个字节，保证不会死循环
  */
static uint8_t utf8_to_codes(const char *s, uint16_t *out, uint8_t max_n)
{
    const uint8_t *p = (const uint8_t *)s;
    uint8_t n = 0U;
    uint32_t c;
    uint8_t k, need;

    while ((*p != 0U) && (n < max_n))
    {
        if (p[0] < 0x80U)                              /* 单字节 ASCII */
        {
            c = p[0];
            need = 1U;
        }
        else if ((p[0] & 0xE0U) == 0xC0U)              /* 双字节 */
        {
            c = p[0] & 0x1FU;
            need = 2U;
        }
        else if ((p[0] & 0xF0U) == 0xE0U)              /* 三字节（常用汉字） */
        {
            c = p[0] & 0x0FU;
            need = 3U;
        }
        else if ((p[0] & 0xF8U) == 0xF0U)              /* 四字节 */
        {
            c = p[0] & 0x07U;
            need = 4U;
        }
        else                                           /* 非法首字节 */
        {
            out[n++] = (uint16_t)'?';
            p++;
            continue;
        }

        if (need > 1U)
        {
            for (k = 1U; k < need; k++)
            {
                if ((p[k] & 0xC0U) != 0x80U)           /* 续字节不合法，说明被截断了 */
                {
                    c = 0xFFFFFFFFU;
                    break;
                }
                c = (c << 6) | (p[k] & 0x3FU);
            }
            if (c == 0xFFFFFFFFU)
            {
                out[n++] = (uint16_t)'?';
                p++;
                continue;
            }
        }

        p += need;
        out[n++] = (c > 0xFFFFU) ? (uint16_t)'?' : (uint16_t)c;
    }

    return n;
}

/* ============================== 归一化 ============================== */
static uint8_t is_drop_code(uint16_t c)
{
    uint16_t i;
    for (i = 0U; i < (uint16_t)(sizeof(DROP_CODES) / sizeof(DROP_CODES[0])); i++)
    {
        if (DROP_CODES[i] == c)
        {
            return 1U;
        }
    }
    return 0U;
}

/**
  * @brief  在一段码点里做「错字 -> 正确写法」替换
  * @note   实现得很直白：从头扫描，每遇到一个位置就试着匹配所有错字规则，
  *         匹配上就把正确写法拷进去，没匹配上就原样拷贝一个码点
  */
static uint8_t apply_typo_fix(const uint16_t *in, uint8_t n, uint16_t *out, uint8_t max_n)
{
    uint16_t wrong_codes[8];
    uint8_t i = 0U, m = 0U, k, wl;
    uint8_t matched;

    while ((i < n) && (m < max_n))
    {
        matched = 0U;
        for (k = 0U; k < TYPO_FIX_NUM; k++)
        {
            wl = utf8_to_codes(TYPO_FIX[k].wrong, wrong_codes, 8U);
            if ((uint8_t)(n - i) >= wl &&
                (memcmp(&in[i], wrong_codes, (size_t)wl * sizeof(uint16_t)) == 0))
            {
                uint16_t right_codes[8];
                uint8_t rl = utf8_to_codes(TYPO_FIX[k].right, right_codes, 8U);
                uint8_t j;
                for (j = 0U; (j < rl) && (m < max_n); j++)
                {
                    out[m++] = right_codes[j];
                }
                i = (uint8_t)(i + wl);
                matched = 1U;
                break;
            }
        }

        if (matched == 0U)
        {
            out[m++] = in[i++];
        }
    }

    return m;
}

/**
  * @brief  归一化：UTF-8 解码 -> 纠错 -> 去标点
  * @retval 处理后的码点数
  */
static uint8_t normalize_text(const char *text, uint16_t *out, uint8_t max_n)
{
    uint8_t n = utf8_to_codes(text, g_tmp, LLM_MAX_CODES);
    uint8_t fixed = apply_typo_fix(g_tmp, n, out, max_n);
    uint8_t i, m = 0U;

    for (i = 0U; i < fixed; i++)
    {
        if (is_drop_code(out[i]) == 0U)
        {
            out[m++] = out[i];
        }
    }

    return m;
}

/* ============================== 特征提取 ============================== */
/**
  * @brief  把一段码点序列的特征按指定权重累加进 feat
  * @note   公式必须和 dataset.featurize 一致：
  *           单字          feat[code % DIM] += 1.0
  *           前邻词组      feat[(prev*31 + code) % DIM] += 1.0
  *           后邻词组      feat[(code*31 + next) % DIM] += 1.0
  *           三字组合      feat[((p2*31 + p1)*31 + code) % DIM] += 0.5
  */
static void add_feature(const uint16_t *codes, uint8_t n, float weight, float *feat)
{
    uint8_t i;
    uint32_t h;

    for (i = 0U; i < n; i++)
    {
        uint16_t code = codes[i];

        feat[code % MODEL_FEAT_DIM] += SINGLE_CHAR_W * weight;

        if (i > 0U)
        {
            h = ((uint32_t)codes[i - 1U] * MODEL_HASH_MUL + code) % MODEL_FEAT_DIM;
            feat[h] += 1.0f * weight;
        }

        if ((uint8_t)(i + 1U) < n)
        {
            h = ((uint32_t)code * MODEL_HASH_MUL + codes[i + 1U]) % MODEL_FEAT_DIM;
            feat[h] += 1.0f * weight;
        }

        if (i >= 2U)
        {
            h = (((uint32_t)codes[i - 2U] * MODEL_HASH_MUL + codes[i - 1U])
                 * MODEL_HASH_MUL + code) % MODEL_FEAT_DIM;
            feat[h] += TRIGRAM_W * weight;
        }
    }
}

/**
  * @brief  算一句话的特征：当前句 + 上一句（加权），最后 L2 归一化
  */
static void build_feature(const uint16_t *cur, uint8_t cur_n,
                          const uint16_t *prev, uint8_t prev_n)
{
    uint16_t i;
    float sum = 0.0f, inv;

    for (i = 0U; i < MODEL_FEAT_DIM; i++)
    {
        g_feat[i] = 0.0f;
    }

    add_feature(cur, cur_n, 1.0f, g_feat);              /* 当前这句话 */
    if (prev_n > 0U)
    {
        add_feature(prev, prev_n, CONTEXT_W, g_feat);   /* 上一句，权重小一点 */
    }

    /* L2 归一化：让长短句的尺度一致 */
    for (i = 0U; i < MODEL_FEAT_DIM; i++)
    {
        sum += g_feat[i] * g_feat[i];
    }
    if (sum > 0.0f)
    {
        inv = 1.0f / sqrtf(sum);
        for (i = 0U; i < MODEL_FEAT_DIM; i++)
        {
            g_feat[i] *= inv;
        }
    }
}

/* ============================== 前向推理 ============================== */
/**
  * @brief  跑一遍两层网络，返回判定出来的类别编号
  * @note   z1 = feat*W1 + b1 -> ReLU -> z2 = h*W2 + b2 -> softmax(z2/温度) -> 取最大
  *         置信度低于阈值就改判 unknown
  */
static uint8_t forward(void)
{
    uint16_t i, j;
    float s, best;
    uint8_t best_id = 0U;

    /* 第一层：1024 -> 64，ReLU */
    for (j = 0U; j < MODEL_HIDDEN; j++)
    {
        s = MODEL_B1[j];
        for (i = 0U; i < MODEL_FEAT_DIM; i++)
        {
            s += g_feat[i] * MODEL_W1[i * MODEL_HIDDEN + j];
        }
        g_hidden[j] = (s > 0.0f) ? s : 0.0f;
    }

    /* 第二层：64 -> 类别数 */
    for (j = 0U; j < MODEL_NUM_CLASS; j++)
    {
        s = MODEL_B2[j];
        for (i = 0U; i < MODEL_HIDDEN; i++)
        {
            s += g_hidden[i] * MODEL_W2[i * MODEL_NUM_CLASS + j];
        }
        g_logits[j] = s;
    }

    /* softmax，注意里面要除以温度（训练时定的，写在 model_weights.h 里） */
    best = g_logits[0];
    for (j = 1U; j < MODEL_NUM_CLASS; j++)
    {
        if (g_logits[j] > best)
        {
            best = g_logits[j];
        }
    }

    s = 0.0f;
    for (j = 0U; j < MODEL_NUM_CLASS; j++)
    {
        g_logits[j] = expf((g_logits[j] - best) / MODEL_TEMPERATURE);
        s += g_logits[j];
    }

    best = -1.0f;
    for (j = 0U; j < MODEL_NUM_CLASS; j++)
    {
        g_logits[j] /= s;
        if (g_logits[j] > best)
        {
            best = g_logits[j];
            best_id = (uint8_t)j;
        }
    }

    /* 置信度太低就承认自己不懂，别硬答 */
    if (best < MODEL_THRESHOLD)
    {
        best_id = (uint8_t)MODEL_UNKNOWN_ID;
    }

    return best_id;
}

/* ============================== 算术解析 ============================== */
/* 规则必须和 dataset.parse_calc 一模一样：
 *   ① 中文运算符换成符号（长的先换，免得"加上"被"加"抢先替换掉）
 *   ② 汉字数字换成阿拉伯数字
 *   ③ 抓出 "数字 运算符 数字" 三段
 *   ④ 算一下，除不尽保留一位小数 */

static uint8_t is_cn_digit(uint16_t c, int32_t *val)
{
    uint8_t i;
    for (i = 0U; i < (uint8_t)CN_DIGIT_NUM; i++)
    {
        if (CN_DIGIT_CODE[i] == c)
        {
            *val = (int32_t)CN_DIGIT_VALUE[i];
            return 1U;
        }
    }
    return 0U;
}

/**
  * @brief  把一段汉字数字转成整数（0~99），解析不了返回 -1
  * @note   支持：三 / 十 / 十五 / 二十 / 三十五
  */
static int32_t cn_number(const uint16_t *codes, uint8_t n)
{
    uint8_t i, shi_pos = 0xFFU;
    int32_t tens = 1, ones = 0, v;

    if (n == 0U)
    {
        return -1;
    }

    for (i = 0U; i < n; i++)
    {
        if (codes[i] == 0x5341U)      /* 十 */
        {
            shi_pos = i;
            break;
        }
    }

    if (shi_pos == 0xFFU)             /* 没有"十"：只支持单个汉字数字 */
    {
        if ((n == 1U) && (is_cn_digit(codes[0], &v) == 1U))
        {
            return v;
        }
        return -1;
    }

    /* 十 前面是几（空则 1） */
    if (shi_pos > 0U)
    {
        if ((shi_pos == 1U) && (is_cn_digit(codes[0], &v) == 1U))
        {
            tens = v;
        }
        else
        {
            return -1;
        }
    }

    /* 十 后面是几（空则 0） */
    if ((uint8_t)(shi_pos + 1U) < n)
    {
        if (((uint8_t)(n - shi_pos - 1U) == 1U) && (is_cn_digit(codes[shi_pos + 1U], &v) == 1U))
        {
            ones = v;
        }
        else
        {
            return -1;
        }
    }

    return tens * 10 + ones;
}

/* 往字符串里追加一个整数，返回新的写入位置 */
static uint8_t append_int(char *out, uint8_t pos, uint8_t max, int32_t v)
{
    char tmp[12];
    uint8_t k = 0U, i;
    uint32_t uv;

    if (v < 0)
    {
        if (pos < max)
        {
            out[pos++] = '-';
        }
        uv = (uint32_t)(-v);
    }
    else
    {
        uv = (uint32_t)v;
    }

    do
    {
        tmp[k++] = (char)('0' + (uv % 10U));
        uv /= 10U;
    } while ((uv > 0U) && (k < 12U));

    for (i = k; i > 0U; i--)
    {
        if (pos < max)
        {
            out[pos++] = tmp[i - 1U];
        }
    }
    return pos;
}

/**
  * @brief  从一句话里解析算术题并计算
  * @param  codes 归一化后的码点序列
  * @retval 1 成功（结果写进 g_calc_buf），0 表示解不出来
  */
static uint8_t parse_calc(const uint16_t *codes, uint8_t n)
{
    uint16_t buf[LLM_MAX_CODES];
    uint8_t m = 0U, i, k;
    int32_t a = 0, b = 0;
    char op = 0;
    uint8_t pos = 0U, seen_a = 0U;
    int32_t r;

    /* ① 中文运算符换成符号 */
    i = 0U;
    while ((i < n) && (m < LLM_MAX_CODES))
    {
        uint16_t c = codes[i];

        if (c == 0x52A0U)                                    /* 加 / 加上 */
        {
            buf[m++] = (uint16_t)'+';
            i++;
            if ((i < n) && (codes[i] == 0x4E0AU)) { i++; }   /* 上 */
        }
        else if (c == 0x51CFU)                               /* 减 / 减去 */
        {
            buf[m++] = (uint16_t)'-';
            i++;
            if ((i < n) && (codes[i] == 0x53BBU)) { i++; }   /* 去 */
        }
        else if (c == 0x4E58U)                               /* 乘 / 乘以 */
        {
            buf[m++] = (uint16_t)'*';
            i++;
            if ((i < n) && (codes[i] == 0x4EE5U)) { i++; }   /* 以 */
        }
        else if (c == 0x9664U)                               /* 除 / 除以 */
        {
            buf[m++] = (uint16_t)'/';
            i++;
            if ((i < n) && (codes[i] == 0x4EE5U)) { i++; }   /* 以 */
        }
        else
        {
            buf[m++] = c;
            i++;
        }
    }

    /* ② 汉字数字换成阿拉伯数字 */
    {
        uint16_t out[LLM_MAX_CODES];
        char num_tmp[12];
        uint8_t o = 0U, start = 0U, in_cn = 0U, np;
        int32_t v, d;

        for (i = 0U; i < m; i++)
        {
            if ((is_cn_digit(buf[i], &d) != 0U) || (buf[i] == 0x5341U))
            {
                if (in_cn == 0U)
                {
                    start = i;
                    in_cn = 1U;
                }
                continue;                      /* 先把连续的汉字数字攒起来 */
            }

            if (in_cn != 0U)                   /* 碰到别的字符，把攒的那段结算掉 */
            {
                v = cn_number(&buf[start], (uint8_t)(i - start));
                if (v < 0)
                {
                    return 0U;
                }
                np = append_int(num_tmp, 0U, 11U, v);
                for (k = 0U; k < np; k++)
                {
                    out[o++] = (uint16_t)num_tmp[k];
                }
                in_cn = 0U;
            }
            out[o++] = buf[i];
        }

        if (in_cn != 0U)                       /* 结尾还攒着一段 */
        {
            v = cn_number(&buf[start], (uint8_t)(m - start));
            if (v < 0)
            {
                return 0U;
            }
            np = append_int(num_tmp, 0U, 11U, v);
            for (k = 0U; k < np; k++)
            {
                out[o++] = (uint16_t)num_tmp[k];
            }
        }

        memcpy(buf, out, (size_t)o * sizeof(uint16_t));
        m = o;
    }

    /* ③ 抓 "数字 运算符 数字" */
    i = 0U;
    while ((i < m) && ((buf[i] < (uint16_t)'0') || (buf[i] > (uint16_t)'9')))
    {
        i++;
    }
    if (i >= m)
    {
        return 0U;
    }
    a = 0;
    seen_a = 0U;
    while ((i < m) && (buf[i] >= (uint16_t)'0') && (buf[i] <= (uint16_t)'9'))
    {
        a = a * 10 + (int32_t)(buf[i] - (uint16_t)'0');
        i++;
        seen_a = 1U;
    }
    if (seen_a == 0U)
    {
        return 0U;
    }

    while ((i < m) && (buf[i] != (uint16_t)'+') && (buf[i] != (uint16_t)'-') &&
           (buf[i] != (uint16_t)'*') && (buf[i] != (uint16_t)'/'))
    {
        i++;
    }
    if (i >= m)
    {
        return 0U;
    }
    op = (char)buf[i];
    i++;

    while ((i < m) && ((buf[i] < (uint16_t)'0') || (buf[i] > (uint16_t)'9')))
    {
        i++;
    }
    if (i >= m)
    {
        return 0U;
    }
    b = 0;
    while ((i < m) && (buf[i] >= (uint16_t)'0') && (buf[i] <= (uint16_t)'9'))
    {
        b = b * 10 + (int32_t)(buf[i] - (uint16_t)'0');
        i++;
    }

    if ((b == 0) && (op == '/'))
    {
        return 0U;
    }

    /* ④ 算，并拼成 "a op b = 结果" */
    pos = 0U;
    pos = append_int(g_calc_buf, pos, 30U, a);
    if (pos < 30U)
    {
        g_calc_buf[pos++] = op;
    }
    pos = append_int(g_calc_buf, pos, 30U, b);
    if (pos < 30U)
    {
        g_calc_buf[pos++] = '=';
    }

    if (op == '+')
    {
        r = a + b;
        pos = append_int(g_calc_buf, pos, 30U, r);
    }
    else if (op == '-')
    {
        r = a - b;
        pos = append_int(g_calc_buf, pos, 30U, r);
    }
    else if (op == '*')
    {
        r = a * b;
        pos = append_int(g_calc_buf, pos, 30U, r);
    }
    else
    {
        if ((a % b) == 0)                        /* 除得尽，显示整数 */
        {
            append_int(g_calc_buf, pos, 30U, a / b);
            pos = (uint8_t)strlen(g_calc_buf);
        }
        else                                     /* 除不尽，保留一位小数 */
        {
            int32_t t10 = (a * 100) / b;         /* 放大 100 倍再除，取整 */
            int32_t ip = t10 / 100;
            int32_t fp = (t10 % 100) / 10;       /* 第一位小数 */

            if ((t10 % 10) >= 5)                 /* 第二位四舍五入 */
            {
                fp++;
                if (fp >= 10)
                {
                    fp = 0;
                    ip++;
                }
            }
            pos = append_int(g_calc_buf, pos, 30U, ip);
            if (pos < 30U)
            {
                g_calc_buf[pos++] = '.';
            }
            if (pos < 30U)
            {
                g_calc_buf[pos++] = (char)('0' + fp);
            }
        }
    }

    g_calc_buf[pos] = '\0';
    return 1U;
}

/* ============================== 对外的接口 ============================== */
const char *LLM_Reply(const char *text)
{
    uint8_t n;
    uint8_t cid;
    const char *resp;
    uint8_t slot;

    /* ① 归一化当前句 */
    n = normalize_text(text, g_cur, LLM_MAX_CODES);

    /* ② 算特征（当前句 + 上一句当上下文） */
    build_feature(g_cur, n, g_prev, g_prev_len);

    /* ③ 推理 */
    cid = forward();

    /* ④ 取回复：同一类有好几条，按轮次轮换，免得每次答得一模一样 */
    slot = (uint8_t)(g_turn % MODEL_RESP_PER_INTENT);

    if (cid == (uint8_t)MODEL_CALC_ID)
    {
        /* 判成算术题：让 parse_calc 真去算；算不出来（说明是被哈希碰撞误判的）
           就改回"不太懂"，这比回"这道题我算不出来"自然得多 */
        if (parse_calc(g_cur, n) != 0U)
        {
            resp = g_calc_buf;
        }
        else
        {
            resp = MODEL_RESPONSES[MODEL_UNKNOWN_ID][slot];
        }
    }
    else
    {
        resp = MODEL_RESPONSES[cid][slot];
    }

    /* ⑤ 把这一句记下来，下一轮当上下文用 */
    if (n > 0U)
    {
        memcpy(g_prev, g_cur, (size_t)n * sizeof(uint16_t));
        g_prev_len = n;
    }
    g_turn++;

    /* 把回复拷进自己的缓冲，方便调用方直接用（MODEL_RESPONSES 里的是常量字符串，
       两种都可以，这里统一走 g_reply 便于以后做替换） */
    if (resp != g_calc_buf)
    {
        strncpy(g_reply, resp, sizeof(g_reply) - 1U);
        g_reply[sizeof(g_reply) - 1U] = '\0';
        resp = g_reply;
    }

    return resp;
}

void LLM_Reset(void)
{
    g_prev_len = 0U;
    g_turn = 0U;
}
