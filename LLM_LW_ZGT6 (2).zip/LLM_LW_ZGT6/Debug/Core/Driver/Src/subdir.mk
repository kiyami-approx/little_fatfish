################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Driver/Src/OLED.c 

OBJS += \
./Core/Driver/Src/OLED.o 

C_DEPS += \
./Core/Driver/Src/OLED.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Driver/Src/%.o Core/Driver/Src/%.su Core/Driver/Src/%.cyclo: ../Core/Driver/Src/%.c Core/Driver/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I"C:/Users/21674/STM32CubeIDE/workspace_1.19.0/LLM_LW_ZGT6/Core/Driver/Inc" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Driver-2f-Src

clean-Core-2f-Driver-2f-Src:
	-$(RM) ./Core/Driver/Src/OLED.cyclo ./Core/Driver/Src/OLED.d ./Core/Driver/Src/OLED.o ./Core/Driver/Src/OLED.su

.PHONY: clean-Core-2f-Driver-2f-Src

